import json
import urllib.parse
import boto3

textract = boto3.client('textract')

def textractProcess(bucket, key):
    try :
        name = key.split('/')[-1]
        print("Textract processing started")
        response = textract.start_document_text_detection(
            DocumentLocation={
                'S3Object': {
                    'Bucket': bucket,
                    'Name': key
                }
            },
            JobTag= name + '_Job',
            NotificationChannel={
                'RoleArn': 'arn:aws:iam::251091134017:role/pdfSnsRole',
                'SNSTopicArn': 'arn:aws:sns:us-east-1:251091134017:pdfQueue'
        })
        print("Textract processing completed")
    except Exception as e:
        print("Error occured during textract process")
        raise(e)
        
def lambda_handler(event, context):
    print("Lambda processing started")
    print("Received s3 event : " + json.dumps(event))
    try:
        for i in range(len(event['Records'])):
            bucket= event['Records'][i]['s3']['bucket']['name']
            key= urllib.parse.unquote_plus(event['Records'][i]['s3']['object']['key'], encoding='utf-8')
            textractProcess(bucket, key)
        return 'Triggered PDF Processing for ' + key
    except Exception as e:
        print(e)
        print("Error getting object ")
        raise e