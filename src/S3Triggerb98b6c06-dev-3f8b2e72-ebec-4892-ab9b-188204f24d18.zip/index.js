// eslint-disable-next-line
var aws =require("aws-sdk");
 
exports.handler = async function (event) {
  
  var s3 = new aws.S3();
  console.log('Received S3 event:', JSON.stringify(event, null, 2));
  
  const source_bucket = "attachments-bucket65310-dev";
  const source_key = event.Records[0].s3.object.key;
  const destination_bucket = "pci.detection.bucket.dev";

  console.log("copyParams doen successfully!!");
  s3.copyObject({
    CopySource : encodeURI(source_bucket + '/' + source_key),
    Bucket:destination_bucket,
    Key : source_key
    }, function(err, data) {
    if(err){
      console.log(err, err.stack); 
    }
    else{
      console.log("Sucessfully uploaded !!!");
    }
  });
  console.log("Hi");
};