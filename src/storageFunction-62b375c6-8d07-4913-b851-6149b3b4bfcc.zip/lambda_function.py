import json
import urllib
import boto3

s3_client=boto3.client('s3')

def isPdf(sourceKey):
    if(sourceKey[-3:] == "pdf"):
        return "non-images/"
    else :
        return "images/"
        
def deleteObjectFromS3Bucket(bucketName,objectKey):
    print('Deleting the Attachment: ',objectKey,' from s3 bucket : ', bucketName)
    try :
        s3_client.delete_object(Bucket= bucketName, Key= objectKey) 
        print('Attachment is deleted successfully') 
    except Exception as e:
        print("Error occurred while deleting attachment")
        print('EventLog : ', e) 
        
def processS3ObjectAndShareResults(sourceBucket, sourceKey):
    destinationBucket = 'pci.detection.bucket.dev'
    copy_object={'Bucket':sourceBucket,'Key':sourceKey}
    fileName = sourceKey.split("/")[-1]
    destinationKey = isPdf(sourceKey) + fileName
    
    try : 
        destinationKey = s3_client.copy_object(CopySource = copy_object,
                            Bucket = destinationBucket,
                            Key = destinationKey
                          )
        deleteObjectFromS3Bucket(sourceBucket, sourceKey)
    except Exception as e :
        print("An error occured wile copying!!")
        print("event log : ", e)
        return e

def lambda_handler(event, context):
    print("Lambda handler processing started")
    print("Received s3 event : " + json.dumps(event))
    try:
        for i in range(len(event['Records'])):
            bucketName = event['Records'][i]['s3']['bucket']['name']
            objectKey = urllib.parse.unquote_plus(event['Records'][i]['s3']['object']['key'], encoding='utf-8')
            processS3ObjectAndShareResults(bucketName, objectKey)
            print("Lambda handler processing completed")
    except Exception as e:
        print('Processing Not completed..Exception raised')
        print('EventLog : ', e)