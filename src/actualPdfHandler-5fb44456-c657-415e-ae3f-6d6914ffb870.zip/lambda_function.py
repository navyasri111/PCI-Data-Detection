import json
import boto3
import os

s3 = boto3.client('s3')
ses = boto3.client('ses')
sqs = boto3.client('sqs')
s3Resource = boto3.resource('s3')
textract = boto3.client('textract')
comprehend = boto3.client('comprehend')

def getJobResults(jobId):
    pages = []
    response = textract.get_document_text_detection(JobId=jobId)
    pages.append(response)
    nextToken = None
    if('NextToken' in response):
        nextToken = response['NextToken']
    while(nextToken):
        response = textract.get_document_text_detection(JobId=jobId, NextToken=nextToken)
        pages.append(response)
        nextToken = None
        if('NextToken' in response):
            nextToken = response['NextToken']
    return pages
    
def getPdfText(pdfTextExtractionStatus, pdfTextExtractionJobId):
    print("Text formation started")
    try:
        pdfText = ''
        if(pdfTextExtractionStatus == 'SUCCEEDED'):
            response = getJobResults(pdfTextExtractionJobId)
            for resultPage in response:
                for item in resultPage["Blocks"]:
                    if item["BlockType"] == "LINE":
                        pdfText += item["Text"] + " "
        print("Text formation completed")
        print("Detected text : ", pdfText)
        return pdfText
    except Exception as e:
        print('Error occurred while text formation is called ..')
        print('EventLog : ', e)
    
    print("Comprehend Processing Started ...")
    try:
        response = comprehend.contains_pii_entities(Text= inputText ,LanguageCode='en')
        print("Comprehend processing completed with response : " + json.dumps(response)) 
        return response
    except ClientError as e:
        print('Error occurred while comprehend is called ..')
        print('EventLog : ', e)

def callComprehendToDetectPiiEntities(inputText):
    print("Comprehend Processing Started ...")
    try:
        response = comprehend.contains_pii_entities(Text= inputText ,LanguageCode='en')
        print("Comprehend processing completed with response : " + json.dumps(response)) 
        return response
    except ClientError as e:
        print('Error occurred while comprehend is called ..')
        print('EventLog : ', e)
        
def doesPCIDataExist(comprehendResponse):
    pciLabelsList = {'BANK_ACCOUNT_NUMBER', 'CREDIT_DEBIT_NUMBER', 'CREDIT_DEBIT_CVV', 'CREDIT_DEBIT_EXPIRY', 'SSN', 'PASSPORT_NUMBER', 'DRIVER_ID', 'PIN','PASSWORD'}
    detectedPciData = []
    for i in range(len(comprehendResponse['Labels'])):
        if comprehendResponse['Labels'][i]['Name'] in pciLabelsList and comprehendResponse['Labels'][i]['Score'] > 0.5 :
            detectedPciData.append(comprehendResponse['Labels'][i]['Name'])
    return detectedPciData

def createMessageforSesifPCI(pdfTextExtractionS3ObjectName, pciLabelsDetected):
    message = 'Management has reported PCI content in the attachment uploaded by you. Please re-upload your attachment after redacting PCI content from it. Information about the PCI and attachment is given below...\n' 
    message += '\nDetected PCI Data : '
    for i in pciLabelsDetected : message += i + ','
    message += '\nPlease do check it and re-upload \n' + 'Thank you!\n'
    return message

def createMessageforSesifnonPCI(objectKey):
    message = 'Management has found the content in the attachment uploaded by you is accurate. It is not having any PCI data. Thankyou for uploading.' 
    return message

def sendMessageViaSes(message, recipientEmails, objectKey):
    print("Message sending via SES...")
    recipientList = recipientEmails.split(',')
    recipient = [str(i).strip() for i in recipientList]
    subjectLine =  "ABOUT ATTACHMENT : " + objectKey.split('/')[-1]
    sourceAct = 'navyasri.j1729@gmail.com'
    bodyPart =  message
    try:
        response = ses.send_email(
            Destination = {
                'ToAddresses': recipient, 
            },
            Message = {
                'Body': {
                   'Text': {
                        'Charset': "UTF-8",
                        'Data': (bodyPart),
                    },
                },
                'Subject': {
                    'Charset': "UTF-8",
                    'Data': subjectLine,
                },
            },
            Source= sourceAct,
        ) 
        print("Message sent via SES!!")
    except ClientError as e:
        print("Error occurred while sending message via SES")
        print('EventLog : ', e)

def deleteObjectFromS3Bucket(pdfTextExtractionS3Bucket,pdfTextExtractionS3ObjectName):
    print('Deleting the Attachment: ',pdfTextExtractionS3ObjectName,' from s3 bucket : ', pdfTextExtractionS3Bucket)
    try :
        s3.delete_object(Bucket= pdfTextExtractionS3Bucket, Key= pdfTextExtractionS3ObjectName) 
        print('Attachment is deleted successfully') 
    except ClientError as e:
        print("Error occurred while deleting attachment")
        print('EventLog : ', e) 

def isPdf(sourceKey):
    if(sourceKey[-3:] == "pdf"):
        return "non-images/"
    else :
        return "images/"
        
def isPCI(isPCIornot):
    if(isPCIornot == True) : return "PCI/"
    else : return "nonPCI/"
    
def storagefunction(sourceBucket, sourceKey, isPCIornot):
    destinationBucket = 'main--bucket'
    copy_object={'Bucket':sourceBucket,'Key':sourceKey}
    fileName = sourceKey.split("/")[-1]
    destinationKey = isPCI(isPCIornot) + isPdf(sourceKey) + fileName
    try : 
        destinationKey = s3.copy_object(CopySource = copy_object,
                            Bucket = destinationBucket,
                            Key = destinationKey
                          )
        deleteObjectFromS3Bucket(sourceBucket, sourceKey)
    except Exception as e :
        print("An error occured wile copying!!")
        print("event log : ", e)
        return e
                   
def lambda_handler(event, context):
    print("Event : " + json.dumps(event))
    print("Started processing information")
    try:
        notificationMessage = json.loads(json.dumps(event))['Records'][0]['Sns']['Message']
        pdfTextExtractionStatus = json.loads(notificationMessage)['Status']
        pdfTextExtractionJobTag = json.loads(notificationMessage)['JobTag']
        pdfTextExtractionJobId = json.loads(notificationMessage)['JobId']
        pdfTextExtractionDocumentLocation = json.loads(notificationMessage)['DocumentLocation']
        pdfTextExtractionS3ObjectName = json.loads(json.dumps(pdfTextExtractionDocumentLocation))['S3ObjectName']
        pdfTextExtractionS3Bucket = json.loads(json.dumps(pdfTextExtractionDocumentLocation))['S3Bucket']
        print(pdfTextExtractionJobTag + ' : ' + pdfTextExtractionStatus)
        pdfText = getPdfText(pdfTextExtractionStatus, pdfTextExtractionJobId)
        comprehendResponse = callComprehendToDetectPiiEntities(pdfText)
        pciLabelsDetected = doesPCIDataExist(comprehendResponse)
        recipientEmails ='pcichecker111@gmail.com'
        print("Information is fetched from metadata")
        isPCIornot = False
        if(pciLabelsDetected):
            isPCIornot = True
            message = createMessageforSesifPCI(pdfTextExtractionS3ObjectName, pciLabelsDetected)
            sendMessageViaSes(message, recipientEmails, pdfTextExtractionS3ObjectName)
        else :
            isPCIornot = False
            message = createMessageforSesifnonPCI(pdfTextExtractionS3ObjectName)
            sendMessageViaSes(message, recipientEmails, pdfTextExtractionS3ObjectName)
        storagefunction(pdfTextExtractionS3Bucket,pdfTextExtractionS3ObjectName, isPCIornot)
    except Exception as e:
        print('Processing Not completed..Exception raised')
        print('EventLog : ', e)